/*imp1.h*/
#ifndef __IMP1_H__
#define __IMP1_H__

#define IMP1_OPS_BASIC  128
#define IMP1_SET        IMP1_OPS_BASIC
#define IMP1_GET        IMP1_OPS_BASIC
#define IMP1_MAX        IMP1_OPS_BASIC+1

#endif
